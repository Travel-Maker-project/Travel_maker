package com.TravelMaker.model;

public class Lodge_Register_ContentDTO {
	private String lodge_Register_Content_AroundInfo;
	private String lodge_Register_Content_StandardInfo;
	private String lodge_Register_Content_AddMemberInfo;
	private String lodge_Register_Content_AminityInfo;
	private String lodge_Register_Content_RuleInfo;
	public String getLodge_Register_Content_AroundInfo() {
		return lodge_Register_Content_AroundInfo;
	}
	public void setLodge_Register_Content_AroundInfo(String lodge_Register_Content_AroundInfo) {
		this.lodge_Register_Content_AroundInfo = lodge_Register_Content_AroundInfo;
	}
	public String getLodge_Register_Content_StandardInfo() {
		return lodge_Register_Content_StandardInfo;
	}
	public void setLodge_Register_Content_StandardInfo(String lodge_Register_Content_StandardInfo) {
		this.lodge_Register_Content_StandardInfo = lodge_Register_Content_StandardInfo;
	}
	public String getLodge_Register_Content_AddMemberInfo() {
		return lodge_Register_Content_AddMemberInfo;
	}
	public void setLodge_Register_Content_AddMemberInfo(String lodge_Register_Content_AddMemberInfo) {
		this.lodge_Register_Content_AddMemberInfo = lodge_Register_Content_AddMemberInfo;
	}
	public String getLodge_Register_Content_AminityInfo() {
		return lodge_Register_Content_AminityInfo;
	}
	public void setLodge_Register_Content_AminityInfo(String lodge_Register_Content_AminityInfo) {
		this.lodge_Register_Content_AminityInfo = lodge_Register_Content_AminityInfo;
	}
	public String getLodge_Register_Content_RuleInfo() {
		return lodge_Register_Content_RuleInfo;
	}
	public void setLodge_Register_Content_RuleInfo(String lodge_Register_Content_RuleInfo) {
		this.lodge_Register_Content_RuleInfo = lodge_Register_Content_RuleInfo;
	}
	
	
}
