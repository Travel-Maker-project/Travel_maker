package com.TravelMaker.repository.promotion;

import org.springframework.stereotype.Repository;

@Repository
public interface PromotionDAO {

	int insertuserCoupon(int couponnum);

	
}
