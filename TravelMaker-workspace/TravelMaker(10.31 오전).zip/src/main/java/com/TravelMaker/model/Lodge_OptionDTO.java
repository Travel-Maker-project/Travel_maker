package com.TravelMaker.model;

public class Lodge_OptionDTO {
	private String lodge_Option_Fiteness;
	private String lodge_Option_SwimmingPool;
	private String lodge_Option_Sauna;
	private String lodge_Option_Restraunt;
	private String lodge_Option_bbq;
	private String lodge_Option_BathRoom;
	private String lodge_Option_Wifi;
	private String lodge_Option_NoneSmoking;
	private String lodge_Option_parking;
	private String lodge_Option_Fordisabled;
	public String getLodge_Option_Fiteness() {
		return lodge_Option_Fiteness;
	}
	public void setLodge_Option_Fiteness(String lodge_Option_Fiteness) {
		this.lodge_Option_Fiteness = lodge_Option_Fiteness;
	}
	public String getLodge_Option_SwimmingPool() {
		return lodge_Option_SwimmingPool;
	}
	public void setLodge_Option_SwimmingPool(String lodge_Option_SwimmingPool) {
		this.lodge_Option_SwimmingPool = lodge_Option_SwimmingPool;
	}
	public String getLodge_Option_Sauna() {
		return lodge_Option_Sauna;
	}
	public void setLodge_Option_Sauna(String lodge_Option_Sauna) {
		this.lodge_Option_Sauna = lodge_Option_Sauna;
	}
	public String getLodge_Option_Restraunt() {
		return lodge_Option_Restraunt;
	}
	public void setLodge_Option_Restraunt(String lodge_Option_Restraunt) {
		this.lodge_Option_Restraunt = lodge_Option_Restraunt;
	}
	public String getLodge_Option_bbq() {
		return lodge_Option_bbq;
	}
	public void setLodge_Option_bbq(String lodge_Option_bbq) {
		this.lodge_Option_bbq = lodge_Option_bbq;
	}
	public String getLodge_Option_BathRoom() {
		return lodge_Option_BathRoom;
	}
	public void setLodge_Option_BathRoom(String lodge_Option_BathRoom) {
		this.lodge_Option_BathRoom = lodge_Option_BathRoom;
	}
	public String getLodge_Option_Wifi() {
		return lodge_Option_Wifi;
	}
	public void setLodge_Option_Wifi(String lodge_Option_Wifi) {
		this.lodge_Option_Wifi = lodge_Option_Wifi;
	}
	public String getLodge_Option_NoneSmoking() {
		return lodge_Option_NoneSmoking;
	}
	public void setLodge_Option_NoneSmoking(String lodge_Option_NoneSmoking) {
		this.lodge_Option_NoneSmoking = lodge_Option_NoneSmoking;
	}
	public String getLodge_Option_parking() {
		return lodge_Option_parking;
	}
	public void setLodge_Option_parking(String lodge_Option_parking) {
		this.lodge_Option_parking = lodge_Option_parking;
	}
	public String getLodge_Option_Fordisabled() {
		return lodge_Option_Fordisabled;
	}
	public void setLodge_Option_Fordisabled(String lodge_Option_Fordisabled) {
		this.lodge_Option_Fordisabled = lodge_Option_Fordisabled;
	}
	
	
}
