package com.TravelMaker.model;

import java.util.Date;

public class Reserved_Lodge_Current_StateDTO {
	private int reserved_Lodge_Current_State_Idx;
	private Date reserved_Lodge_Current_State_Date;
	private String reserved_Lodge_Current_State_UserId;
	private int reserved_Lodge_Current_State_RoomIdx;
	public int getReserved_Lodge_Current_State_Idx() {
		return reserved_Lodge_Current_State_Idx;
	}
	public void setReserved_Lodge_Current_State_Idx(int reserved_Lodge_Current_State_Idx) {
		this.reserved_Lodge_Current_State_Idx = reserved_Lodge_Current_State_Idx;
	}
	public Date getReserved_Lodge_Current_State_Date() {
		return reserved_Lodge_Current_State_Date;
	}
	public void setReserved_Lodge_Current_State_Date(Date reserved_Lodge_Current_State_Date) {
		this.reserved_Lodge_Current_State_Date = reserved_Lodge_Current_State_Date;
	}
	public String getReserved_Lodge_Current_State_UserId() {
		return reserved_Lodge_Current_State_UserId;
	}
	public void setReserved_Lodge_Current_State_UserId(String reserved_Lodge_Current_State_UserId) {
		this.reserved_Lodge_Current_State_UserId = reserved_Lodge_Current_State_UserId;
	}
	public int getReserved_Lodge_Current_State_RoomIdx() {
		return reserved_Lodge_Current_State_RoomIdx;
	}
	public void setReserved_Lodge_Current_State_RoomIdx(int reserved_Lodge_Current_State_RoomIdx) {
		this.reserved_Lodge_Current_State_RoomIdx = reserved_Lodge_Current_State_RoomIdx;
	}
	
	
	
	
}
