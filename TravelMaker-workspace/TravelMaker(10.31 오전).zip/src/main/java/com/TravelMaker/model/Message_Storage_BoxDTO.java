package com.TravelMaker.model;

import java.util.Date;

public class Message_Storage_BoxDTO {
	private int message_Storage_Box_Idx;
	private Date message_Storage_Box_Date;
	private String message_Storage_Box_Content;
	private String message_Storage_Box_IsRead;
	private String message_Storage_Box_IsConfirm;
	private String message_Storage_Box_GiveUser;
	private String message_Storage_Box_TakeUser;
	public int getMessage_Storage_Box_Idx() {
		return message_Storage_Box_Idx;
	}
	public void setMessage_Storage_Box_Idx(int message_Storage_Box_Idx) {
		this.message_Storage_Box_Idx = message_Storage_Box_Idx;
	}
	public Date getMessage_Storage_Box_Date() {
		return message_Storage_Box_Date;
	}
	public void setMessage_Storage_Box_Date(Date message_Storage_Box_Date) {
		this.message_Storage_Box_Date = message_Storage_Box_Date;
	}
	public String getMessage_Storage_Box_Content() {
		return message_Storage_Box_Content;
	}
	public void setMessage_Storage_Box_Content(String message_Storage_Box_Content) {
		this.message_Storage_Box_Content = message_Storage_Box_Content;
	}
	public String getMessage_Storage_Box_IsRead() {
		return message_Storage_Box_IsRead;
	}
	public void setMessage_Storage_Box_IsRead(String message_Storage_Box_IsRead) {
		this.message_Storage_Box_IsRead = message_Storage_Box_IsRead;
	}
	public String getMessage_Storage_Box_IsConfirm() {
		return message_Storage_Box_IsConfirm;
	}
	public void setMessage_Storage_Box_IsConfirm(String message_Storage_Box_IsConfirm) {
		this.message_Storage_Box_IsConfirm = message_Storage_Box_IsConfirm;
	}
	public String getMessage_Storage_Box_GiveUser() {
		return message_Storage_Box_GiveUser;
	}
	public void setMessage_Storage_Box_GiveUser(String message_Storage_Box_GiveUser) {
		this.message_Storage_Box_GiveUser = message_Storage_Box_GiveUser;
	}
	public String getMessage_Storage_Box_TakeUser() {
		return message_Storage_Box_TakeUser;
	}
	public void setMessage_Storage_Box_TakeUser(String message_Storage_Box_TakeUser) {
		this.message_Storage_Box_TakeUser = message_Storage_Box_TakeUser;
	}
	
}
