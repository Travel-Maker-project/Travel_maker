package com.TravelMaker.model;

import java.util.Date;

public class Metting_BoardDTO {
	private int Metting_Board_Idx;
	private Date Metting_Board_Date;
	private String Metting_Board_Content;
	private String Metting_Board_Location;
	private String Metting_Board_Writer;
	private String Metting_Board_IsDeleted;
	public int getMetting_Board_Idx() {
		return Metting_Board_Idx;
	}
	public void setMetting_Board_Idx(int metting_Board_Idx) {
		Metting_Board_Idx = metting_Board_Idx;
	}
	public Date getMetting_Board_Date() {
		return Metting_Board_Date;
	}
	public void setMetting_Board_Date(Date metting_Board_Date) {
		Metting_Board_Date = metting_Board_Date;
	}
	public String getMetting_Board_Content() {
		return Metting_Board_Content;
	}
	public void setMetting_Board_Content(String metting_Board_Content) {
		Metting_Board_Content = metting_Board_Content;
	}
	public String getMetting_Board_Location() {
		return Metting_Board_Location;
	}
	public void setMetting_Board_Location(String metting_Board_Location) {
		Metting_Board_Location = metting_Board_Location;
	}
	public String getMetting_Board_Writer() {
		return Metting_Board_Writer;
	}
	public void setMetting_Board_Writer(String metting_Board_Writer) {
		Metting_Board_Writer = metting_Board_Writer;
	}
	public String getMetting_Board_IsDeleted() {
		return Metting_Board_IsDeleted;
	}
	public void setMetting_Board_IsDeleted(String metting_Board_IsDeleted) {
		Metting_Board_IsDeleted = metting_Board_IsDeleted;
	}
}
