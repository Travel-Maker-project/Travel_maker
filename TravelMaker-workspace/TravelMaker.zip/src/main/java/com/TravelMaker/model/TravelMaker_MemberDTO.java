package com.TravelMaker.model;

import java.util.Date;

public class TravelMaker_MemberDTO {
	private int TravelMaker_Member_Idx;
	private String TravelMaker_Member_UserId;
	private String TravelMaker_Member_UserPw;
	private String TravelMaker_Member_Sort;
	private String TravelMaker_Member_UserName;
	private String TravelMaker_Member_UserNickName;
	private String TravelMaker_Member_Email;
	private Date TravelMaker_Member_Birth;
	private String TravelMaker_Member_Gender;
	private String TravelMaker_Member_RealProfileImg;
	private String TravelMaker_Member_EncodingProfilImg;
	private String TravelMaker_Member_Pnum;
	private int TravelMaker_Member_ReservedLodge;
	private String TravelMaker_Member_IsAdmin;
	private String TravelMaker_Member_Favorite;
	private int TravelMaker_Member_Coupon;
	private String TravelMaker_Member_IsExist;
	public int getTravelMaker_Member_Idx() {
		return TravelMaker_Member_Idx;
	}
	public void setTravelMaker_Member_Idx(int travelMaker_Member_Idx) {
		TravelMaker_Member_Idx = travelMaker_Member_Idx;
	}
	public String getTravelMaker_Member_UserId() {
		return TravelMaker_Member_UserId;
	}
	public void setTravelMaker_Member_UserId(String travelMaker_Member_UserId) {
		TravelMaker_Member_UserId = travelMaker_Member_UserId;
	}
	public String getTravelMaker_Member_UserPw() {
		return TravelMaker_Member_UserPw;
	}
	public void setTravelMaker_Member_UserPw(String travelMaker_Member_UserPw) {
		TravelMaker_Member_UserPw = travelMaker_Member_UserPw;
	}
	public String getTravelMaker_Member_Sort() {
		return TravelMaker_Member_Sort;
	}
	public void setTravelMaker_Member_Sort(String travelMaker_Member_Sort) {
		TravelMaker_Member_Sort = travelMaker_Member_Sort;
	}
	public String getTravelMaker_Member_UserName() {
		return TravelMaker_Member_UserName;
	}
	public void setTravelMaker_Member_UserName(String travelMaker_Member_UserName) {
		TravelMaker_Member_UserName = travelMaker_Member_UserName;
	}
	public String getTravelMaker_Member_UserNickName() {
		return TravelMaker_Member_UserNickName;
	}
	public void setTravelMaker_Member_UserNickName(String travelMaker_Member_UserNickName) {
		TravelMaker_Member_UserNickName = travelMaker_Member_UserNickName;
	}
	public String getTravelMaker_Member_Email() {
		return TravelMaker_Member_Email;
	}
	public void setTravelMaker_Member_Email(String travelMaker_Member_Email) {
		TravelMaker_Member_Email = travelMaker_Member_Email;
	}
	public Date getTravelMaker_Member_Birth() {
		return TravelMaker_Member_Birth;
	}
	public void setTravelMaker_Member_Birth(Date travelMaker_Member_Birth) {
		TravelMaker_Member_Birth = travelMaker_Member_Birth;
	}
	public String getTravelMaker_Member_Gender() {
		return TravelMaker_Member_Gender;
	}
	public void setTravelMaker_Member_Gender(String travelMaker_Member_Gender) {
		TravelMaker_Member_Gender = travelMaker_Member_Gender;
	}
	public String getTravelMaker_Member_RealProfileImg() {
		return TravelMaker_Member_RealProfileImg;
	}
	public void setTravelMaker_Member_RealProfileImg(String travelMaker_Member_RealProfileImg) {
		TravelMaker_Member_RealProfileImg = travelMaker_Member_RealProfileImg;
	}
	public String getTravelMaker_Member_EncodingProfilImg() {
		return TravelMaker_Member_EncodingProfilImg;
	}
	public void setTravelMaker_Member_EncodingProfilImg(String travelMaker_Member_EncodingProfilImg) {
		TravelMaker_Member_EncodingProfilImg = travelMaker_Member_EncodingProfilImg;
	}
	public String getTravelMaker_Member_Pnum() {
		return TravelMaker_Member_Pnum;
	}
	public void setTravelMaker_Member_Pnum(String travelMaker_Member_Pnum) {
		TravelMaker_Member_Pnum = travelMaker_Member_Pnum;
	}
	public int getTravelMaker_Member_ReservedLodge() {
		return TravelMaker_Member_ReservedLodge;
	}
	public void setTravelMaker_Member_ReservedLodge(int travelMaker_Member_ReservedLodge) {
		TravelMaker_Member_ReservedLodge = travelMaker_Member_ReservedLodge;
	}
	public String getTravelMaker_Member_IsAdmin() {
		return TravelMaker_Member_IsAdmin;
	}
	public void setTravelMaker_Member_IsAdmin(String travelMaker_Member_IsAdmin) {
		TravelMaker_Member_IsAdmin = travelMaker_Member_IsAdmin;
	}
	public String getTravelMaker_Member_Favorite() {
		return TravelMaker_Member_Favorite;
	}
	public void setTravelMaker_Member_Favorite(String travelMaker_Member_Favorite) {
		TravelMaker_Member_Favorite = travelMaker_Member_Favorite;
	}
	public int getTravelMaker_Member_Coupon() {
		return TravelMaker_Member_Coupon;
	}
	public void setTravelMaker_Member_Coupon(int travelMaker_Member_Coupon) {
		TravelMaker_Member_Coupon = travelMaker_Member_Coupon;
	}
	public String getTravelMaker_Member_IsExist() {
		return TravelMaker_Member_IsExist;
	}
	public void setTravelMaker_Member_IsExist(String travelMaker_Member_IsExist) {
		TravelMaker_Member_IsExist = travelMaker_Member_IsExist;
	}
}
