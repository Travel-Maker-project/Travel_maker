package com.TravelMaker.model;

public class Lodge_OptionDTO {
	private String Lodge_Option_Fiteness;
	private String Lodge_Option_SwimmingPool;
	private String Lodge_Option_Sauna;
	private String Lodge_Option_Restraunt;
	private String Lodge_Option_bbq;
	private String Lodge_Option_BathRoom;
	private String Lodge_Option_Wifi;
	private String Lodge_Option_NoneSmoking;
	private String Lodge_Option_parking;
	private String Lodge_Option_Fordisabled;
	public String getLodge_Option_Fiteness() {
		return Lodge_Option_Fiteness;
	}
	public void setLodge_Option_Fiteness(String lodge_Option_Fiteness) {
		Lodge_Option_Fiteness = lodge_Option_Fiteness;
	}
	public String getLodge_Option_SwimmingPool() {
		return Lodge_Option_SwimmingPool;
	}
	public void setLodge_Option_SwimmingPool(String lodge_Option_SwimmingPool) {
		Lodge_Option_SwimmingPool = lodge_Option_SwimmingPool;
	}
	public String getLodge_Option_Sauna() {
		return Lodge_Option_Sauna;
	}
	public void setLodge_Option_Sauna(String lodge_Option_Sauna) {
		Lodge_Option_Sauna = lodge_Option_Sauna;
	}
	public String getLodge_Option_Restraunt() {
		return Lodge_Option_Restraunt;
	}
	public void setLodge_Option_Restraunt(String lodge_Option_Restraunt) {
		Lodge_Option_Restraunt = lodge_Option_Restraunt;
	}
	public String getLodge_Option_bbq() {
		return Lodge_Option_bbq;
	}
	public void setLodge_Option_bbq(String lodge_Option_bbq) {
		Lodge_Option_bbq = lodge_Option_bbq;
	}
	public String getLodge_Option_BathRoom() {
		return Lodge_Option_BathRoom;
	}
	public void setLodge_Option_BathRoom(String lodge_Option_BathRoom) {
		Lodge_Option_BathRoom = lodge_Option_BathRoom;
	}
	public String getLodge_Option_Wifi() {
		return Lodge_Option_Wifi;
	}
	public void setLodge_Option_Wifi(String lodge_Option_Wifi) {
		Lodge_Option_Wifi = lodge_Option_Wifi;
	}
	public String getLodge_Option_NoneSmoking() {
		return Lodge_Option_NoneSmoking;
	}
	public void setLodge_Option_NoneSmoking(String lodge_Option_NoneSmoking) {
		Lodge_Option_NoneSmoking = lodge_Option_NoneSmoking;
	}
	public String getLodge_Option_parking() {
		return Lodge_Option_parking;
	}
	public void setLodge_Option_parking(String lodge_Option_parking) {
		Lodge_Option_parking = lodge_Option_parking;
	}
	public String getLodge_Option_Fordisabled() {
		return Lodge_Option_Fordisabled;
	}
	public void setLodge_Option_Fordisabled(String lodge_Option_Fordisabled) {
		Lodge_Option_Fordisabled = lodge_Option_Fordisabled;
	}
	
	
}
