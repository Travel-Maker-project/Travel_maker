package com.TravelMaker.model;

public class Lodge_Register_SellerInfoDTO {
	private String Lodge_Register_SellerInfo_BusinessNum;
	private String Lodge_Register_SellerInfo_Address;
	private String Lodge_Register_SellerInfo_CeoName;
	private String Lodge_Register_SellerInfo_Tel;
	private String Lodge_Register_SellerInfo_Email;
	public String getLodge_Register_SellerInfo_BusinessNum() {
		return Lodge_Register_SellerInfo_BusinessNum;
	}
	public void setLodge_Register_SellerInfo_BusinessNum(String lodge_Register_SellerInfo_BusinessNum) {
		Lodge_Register_SellerInfo_BusinessNum = lodge_Register_SellerInfo_BusinessNum;
	}
	public String getLodge_Register_SellerInfo_Address() {
		return Lodge_Register_SellerInfo_Address;
	}
	public void setLodge_Register_SellerInfo_Address(String lodge_Register_SellerInfo_Address) {
		Lodge_Register_SellerInfo_Address = lodge_Register_SellerInfo_Address;
	}
	public String getLodge_Register_SellerInfo_CeoName() {
		return Lodge_Register_SellerInfo_CeoName;
	}
	public void setLodge_Register_SellerInfo_CeoName(String lodge_Register_SellerInfo_CeoName) {
		Lodge_Register_SellerInfo_CeoName = lodge_Register_SellerInfo_CeoName;
	}
	public String getLodge_Register_SellerInfo_Tel() {
		return Lodge_Register_SellerInfo_Tel;
	}
	public void setLodge_Register_SellerInfo_Tel(String lodge_Register_SellerInfo_Tel) {
		Lodge_Register_SellerInfo_Tel = lodge_Register_SellerInfo_Tel;
	}
	public String getLodge_Register_SellerInfo_Email() {
		return Lodge_Register_SellerInfo_Email;
	}
	public void setLodge_Register_SellerInfo_Email(String lodge_Register_SellerInfo_Email) {
		Lodge_Register_SellerInfo_Email = lodge_Register_SellerInfo_Email;
	}
	
	
}
