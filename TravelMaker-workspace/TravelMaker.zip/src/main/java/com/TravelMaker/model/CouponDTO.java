package com.TravelMaker.model;

public class CouponDTO {
	private int Coupon_idx;
	private String Coupon_name;
	private String Coupon_Validdate;
	private int Coupon_SalePrice;
	private String Coupon_content;
	private int Coupon_Type;
	public int getCoupon_idx() {
		return Coupon_idx;
	}
	public void setCoupon_idx(int coupon_idx) {
		Coupon_idx = coupon_idx;
	}
	public String getCoupon_name() {
		return Coupon_name;
	}
	public void setCoupon_name(String coupon_name) {
		Coupon_name = coupon_name;
	}
	public String getCoupon_Validdate() {
		return Coupon_Validdate;
	}
	public void setCoupon_Validdate(String coupon_Validdate) {
		Coupon_Validdate = coupon_Validdate;
	}
	public int getCoupon_SalePrice() {
		return Coupon_SalePrice;
	}
	public void setCoupon_SalePrice(int coupon_SalePrice) {
		Coupon_SalePrice = coupon_SalePrice;
	}
	public String getCoupon_content() {
		return Coupon_content;
	}
	public void setCoupon_content(String coupon_content) {
		Coupon_content = coupon_content;
	}
	public int getCoupon_Type() {
		return Coupon_Type;
	}
	public void setCoupon_Type(int coupon_Type) {
		Coupon_Type = coupon_Type;
	}
	
	
}
