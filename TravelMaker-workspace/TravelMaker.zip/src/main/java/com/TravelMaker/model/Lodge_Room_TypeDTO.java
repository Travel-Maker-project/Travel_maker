package com.TravelMaker.model;

public class Lodge_Room_TypeDTO {
	private int Lodge_Room_Type_Idx;
	private String Lodge_Room_Type_Name;
	private int Lodge_Room_Type_MinCapacity;
	private int Lodge_Room_Type_MaxCapacity;
	private String Lodge_Room_Type_Option;
	private String Lodge_Room_Type_Img;
	private int Lodge_Room_Type_price;
	private int Lodge_Room_Type_Count;
	private int Lodge_Idx;
	private int Lodge_Room_Type_Coupon;
	private String Lodge_Room_Type_IsDeleted;
	public int getLodge_Room_Type_Idx() {
		return Lodge_Room_Type_Idx;
	}
	public void setLodge_Room_Type_Idx(int lodge_Room_Type_Idx) {
		Lodge_Room_Type_Idx = lodge_Room_Type_Idx;
	}
	public String getLodge_Room_Type_Name() {
		return Lodge_Room_Type_Name;
	}
	public void setLodge_Room_Type_Name(String lodge_Room_Type_Name) {
		Lodge_Room_Type_Name = lodge_Room_Type_Name;
	}
	public int getLodge_Room_Type_MinCapacity() {
		return Lodge_Room_Type_MinCapacity;
	}
	public void setLodge_Room_Type_MinCapacity(int lodge_Room_Type_MinCapacity) {
		Lodge_Room_Type_MinCapacity = lodge_Room_Type_MinCapacity;
	}
	public int getLodge_Room_Type_MaxCapacity() {
		return Lodge_Room_Type_MaxCapacity;
	}
	public void setLodge_Room_Type_MaxCapacity(int lodge_Room_Type_MaxCapacity) {
		Lodge_Room_Type_MaxCapacity = lodge_Room_Type_MaxCapacity;
	}
	public String getLodge_Room_Type_Option() {
		return Lodge_Room_Type_Option;
	}
	public void setLodge_Room_Type_Option(String lodge_Room_Type_Option) {
		Lodge_Room_Type_Option = lodge_Room_Type_Option;
	}
	public String getLodge_Room_Type_Img() {
		return Lodge_Room_Type_Img;
	}
	public void setLodge_Room_Type_Img(String lodge_Room_Type_Img) {
		Lodge_Room_Type_Img = lodge_Room_Type_Img;
	}
	public int getLodge_Room_Type_price() {
		return Lodge_Room_Type_price;
	}
	public void setLodge_Room_Type_price(int lodge_Room_Type_price) {
		Lodge_Room_Type_price = lodge_Room_Type_price;
	}
	public int getLodge_Room_Type_Count() {
		return Lodge_Room_Type_Count;
	}
	public void setLodge_Room_Type_Count(int lodge_Room_Type_Count) {
		Lodge_Room_Type_Count = lodge_Room_Type_Count;
	}
	public int getLodge_Idx() {
		return Lodge_Idx;
	}
	public void setLodge_Idx(int lodge_Idx) {
		Lodge_Idx = lodge_Idx;
	}
	public int getLodge_Room_Type_Coupon() {
		return Lodge_Room_Type_Coupon;
	}
	public void setLodge_Room_Type_Coupon(int lodge_Room_Type_Coupon) {
		Lodge_Room_Type_Coupon = lodge_Room_Type_Coupon;
	}
	public String getLodge_Room_Type_IsDeleted() {
		return Lodge_Room_Type_IsDeleted;
	}
	public void setLodge_Room_Type_IsDeleted(String lodge_Room_Type_IsDeleted) {
		Lodge_Room_Type_IsDeleted = lodge_Room_Type_IsDeleted;
	}
}
