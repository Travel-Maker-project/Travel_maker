package com.TravelMaker.service.member;

import com.TravelMaker.component.HashComponent;
import com.TravelMaker.model.TravelMaker_MemberDTO;
import com.TravelMaker.repository.member.MemberDAO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MemberService {

    @Autowired private MemberDAO memberDAO;
    @Autowired private HashComponent hashComponent;


    public int join(TravelMaker_MemberDTO dto) {
        String salt = hashComponent.getRandomSalt();
        String hash = hashComponent.getHash(dto.getTravelMaker_Member_UserPw(), salt);
        dto.setTravelMaker_Member_UserPw(hash);
        dto.setTravelMaker_Member_Sort(salt);

        return memberDAO.insertMember(dto);
    }


//    public TravelMaker_MemberDTO selectOneById(String travelMakerMemberUserId) {
//        System.out.println("travelMakerMemberUserId: " + travelMakerMemberUserId);
//        return memberDAO.selectOneById(travelMakerMemberUserId);
//    }
    // 작업중
}
