package com.TravelMaker.controller.member;

import com.TravelMaker.model.TravelMaker_MemberDTO;
import com.TravelMaker.service.member.MemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.TravelMaker.component.MailComponent;

import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.Random;

@RestController
@RequestMapping("/ajax")
public class MemberAjaxController {

    @Autowired private MailComponent mailComponent;
    @Autowired private MemberService memberService;

    private Random ran = new Random();

    // 1) 이메일로 임의의 인증번호를 보낸다.
    @GetMapping("/sendAuthNumber")
    public String sendAuthNumber(String email, HttpSession session){
        String authNumber = (ran.nextInt(899999) + 100000) + "";

        HashMap<String, String> param = new HashMap<>();
        param.put("receiver", email);
        param.put("subject", "[Travel Maker] 가입 인증 번호");
        param.put("content", authNumber);

        int row = mailComponent.sendMimeMessage(param);

        String msg;
        if(row != 1 ){
            msg = "인증번호 발송에 실패 했습니다.";
        }
        else {
            msg = "인증번호가 발송 되었습니다.";
            session.setAttribute("authNumber", authNumber);
            session.setMaxInactiveInterval(600);
        }
        return msg;
    }

    // 2) 사용자가 확인용으로 입력한 인증번호와 세션에 저장된 인증번호를 비교하여 일치여부를 반환한다.
    @GetMapping("/checkAuthNumber/{userNumber}")
    public String checkAuthNumber(@PathVariable("userNumber")
                                      String userNumber, HttpSession session) {
        String sessionNumber = (String) session.getAttribute("authNumber");
        String result = userNumber.equals(sessionNumber) ? "1" : "0";
        return result;
    }

//    @GetMapping("/checkDuplicationId")
//    public String checkDuplicationId(String travelMaker_Member_UserId){
//        System.out.println(travelMaker_Member_UserId);
//        TravelMaker_MemberDTO dto = memberService.selectOneById(travelMaker_Member_UserId);
//        System.out.println("dto :" + dto);
//        System.out.println(travelMaker_Member_UserId);
//        String msg = dto == null ? "사용 가능한 ID" : "중복된 ID";
//
//        System.out.println(msg);
//        return msg;
//
//    }
    // 작업 중
}
